

/**
 * @fileoverview Store configuration variables for tests.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.TestConfVars');


/**
 * Enum to store various configuration variables for tests.
 * @enum {number}
 */
ccd.TestConfVars = {
  XHR_TIMEOUT_MILSEC: 700,

  RESOLVER_LATENCY_SLEEP_MILSEC: 100,

  TOTAL_TESTS_TIMEOUT_SEC: 120,

  XHR_SLEEP_MILSEC: 200
};
