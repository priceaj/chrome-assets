// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview Test whether a captive portal is present and implemented
 *   via DNS.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.CaptivePortalDnsTest');

goog.require('ccd.Test');
goog.require('ccd.TestConfVars');
goog.require('ccd.TestId');
goog.require('ccd.TestResult');
goog.require('ccd.TestVerdict');



/**
 * Test whether a captive portal is present and implemented by DNS.
 * @constructor
 * @extends {ccd.Test}
 */
ccd.CaptivePortalDnsTest = function() {
  this.testResult = new ccd.TestResult(ccd.TestId.CAPTIVE_PORTAL_DNS);

  /**
   * The number of hostnames that have been tested to detemine whether a
   *   captive portal is present.
   * @private {number}
   */
  this.numTestsCompleted_ = 0;

  /**
   * Store address returned by DNS resolution.
   * @private {!Array.<string>}
   */
  this.resolutionResultsString_ = [];


  /**
   * Store DNS resolution status code.
   * @see #chromium/src/net/base/net_error_list.h
   * @private {!Array.<number>}
   */
  this.resolutionResultsCode_ = [];

  /**
   * @private {number}
   */
  this.timeoutId_ = 0;

  /**
   * @private {Array.<string>}
   * @const
   */
  this.knownHostnamesToQuery_ = ['ccd-testing-v4.gstatic.com'];
};


/** @type {ccd.Test} */
ccd.CaptivePortalDnsTest.prototype = new ccd.Test();


/** @type {function(new:ccd.Test)} */
ccd.CaptivePortalDnsTest.prototype.constructor = ccd.Test;


/** @type {ccd.Test} */
ccd.CaptivePortalDnsTest.prototype.parent =
    /** @type {ccd.Test} */ (ccd.Test.prototype);


/**
 * @private {number}
 * @const
 */
ccd.CaptivePortalDnsTest.NUM_RANDOM_HOSTS_CAPTIVE_PORTAL_DNS_TEST_ = 5;


/**
 * @private {number}
 * @see #chromium/src/net/base/net_error_list.h
 * @const
 */
ccd.CaptivePortalDnsTest.INTERNET_DISCONNECTED_STATUS_CODE_ = -106;


/**
 * Determine whether the computer is disconnected from the network and as such
 *   could reasonably expect consistent DNS status code results.
 * @return {boolean} Whether the network is disconnected.
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.isNetworkDisconnected_ = function() {
  var numDisconnectedResults = 0;
  for (var i = 0; i < this.resolutionResultsCode_.length; i++) {
    if (this.resolutionResultsCode_[i] ==
        ccd.CaptivePortalDnsTest.INTERNET_DISCONNECTED_STATUS_CODE_) {
      numDisconnectedResults++;
    }
  }

  // After having computed the number of DNS resolutions that returned
  //   a result indicating that the internet is disconnected,
  //   check to see if this number of greater than 80% of the total
  //   number of hosts we tried to query. If it is, assume that the
  //   network is disconnected. We do not go with 100% as the threshold
  //   due to the possibility of caching.
  return (numDisconnectedResults >= 0.8 * this.resolutionResultsCode_.length);
};


/**
 * Determine whether a DNS captive portal exists.
 * @return {boolean} Whether a DNS captive portal was detected.
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.isProblemDetected_ = function() {
  var numHostsWithSameIp = 0;

  // Check Google hosts.
  // Known Google host queries (i.e., queries to ccd-testing-v4.gstatic.com)
  //   should return 216.239.3{2,4,6,8}.21
  for (var i = 0; i < this.knownHostnamesToQuery_.length; i++) {
    if (this.resolutionResultsString_[i] != '216.239.32.21' &&
        this.resolutionResultsString_[i] != '216.239.34.21' &&
        this.resolutionResultsString_[i] != '216.239.36.21' &&
        this.resolutionResultsString_[i] != '216.239.38.21') {
      return true;
    }
  }

  // Check random hosts.
  for (var i = this.knownHostnamesToQuery_.length + 1;
       i < this.resolutionResultsString_.length; i++) {
    if (this.resolutionResultsString_[i] ==
        this.resolutionResultsString_[i - i]) {
      numHostsWithSameIp++;
    }
  }

  // There is no perfect science about choosing a threshold, but
  //   based upon trial and error with various networks, 60%
  //   worked well.
  return (numHostsWithSameIp >= 0.6 * this.resolutionResultsString_.length);
};


/**
 * Determine whether a DNS captive portal potentially exists.
 * @return {boolean} Whether a DNS captive portal was potentially detected.
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.isPotentialProblemDetected_ = function() {
  // Check the random hosts; see if they do not resolve all to the same IP.
  // Unfortuantely, we cannot check to see if they resolve as some ISPs
  //   will have a DNS not found landing page (e.g. the IP for
  //   http://search.dnsassist.verizon.net is returned on Verizon for
  //   hostnames that don't exist).

  // After testing in the wild, there is no clean / perfect way to do this.
  //   Consequently, we will use a point system to add up the number of
  //   potentially questionable results. If enough points occurred, then
  //   we return that a potential problem occurred.
  var numQuestionableResultPoints = 0;


  // Check the known hostnames. For each known hostname with the same IP,
  //   count it as a point toward a potential problem.
  for (var i = 1; i < this.knownHostnamesToQuery_.length; i++) {
    if (this.knownHostnamesToQuery_[i] ==
        this.knownHostnamesToQuery_[i - i]) {
      numQuestionableResultPoints++;
    }
  }

  // Check the random hostnames, which should not exist.
  for (var i = this.knownHostnamesToQuery_.length;
       i < this.resolutionResultsString_.length; i++) {
    // In testing, some ISPs did not consistently return the IP of a
    //   search page even for hostnames that did not exist.
    // Consequently, we will count the number of random IPs that differ
    //   in their hostname as a potential problem and will not count
    //   returning a IP for a hostname that doesn't exist as a failure.
    //   We will also ignore empty IP results (i.e., null) as this is
    //   expected on a normal network.
    if ((this.resolutionResultsString_[i] != null) &&
        (this.resolutionResultsString_[i] !=
        this.resolutionResultsString_[i - 1])) {
      numQuestionableResultPoints++;
    }

    // In theory, result code should always be -105 since these hostnames
    //   do not exist. However, some networks serve the IP of a search
    //   page for all hostnames that don't exist, meaning we could
    //   legitimately get a resultCode == 0 and not have a captive portal.
    if (this.resolutionResultsCode_[i] == 0) {
      numQuestionableResultPoints++;
    }
  }

  // There is no perfect science about choosing a threshold, but
  //   based upon trial and error with various networks, 60%
  //   worked well.
  var potentialProblemThreashold =
      (0.6 * this.knownHostnamesToQuery_.length) +
      (0.6 * ccd.CaptivePortalDnsTest.
          NUM_RANDOM_HOSTS_CAPTIVE_PORTAL_DNS_TEST_);
  return (numQuestionableResultPoints >= potentialProblemThreashold);
};


/**
 * @override
 */
ccd.CaptivePortalDnsTest.prototype.analyzeResults = function() {
  // Assume no problem; change/update this if things change.
  this.testResult.setTestVerdict(ccd.TestVerdict.NO_PROBLEM);
  this.testResult.setTitle(
      chrome.i18n.getMessage('captiveportaldnstest_noproblem_title'));
  this.testResult.setSubtitle(
      chrome.i18n.getMessage('captiveportaldnstest_noproblem_subtitle'));

  // Check whether the network is likely disconnected based upon DNS
  //   status code. If so, don't show a captive portal DNS.
  if (this.isNetworkDisconnected_()) {
    // TODO(ebeach): add log message that the internet is disconnected.
    return;
  }

  if (this.isProblemDetected_()) {
    this.testResult.setTestVerdict(ccd.TestVerdict.PROBLEM);
    this.testResult.setTitle(
        chrome.i18n.getMessage('captiveportaldnstest_problem_title'));
    this.testResult.setSubtitle(
        chrome.i18n.getMessage('captiveportaldnstest_problem_subtitle'));
  } else if (this.isPotentialProblemDetected_()) {
    this.testResult.setTestVerdict(ccd.TestVerdict.POTENTIAL_PROBLEM);
    this.testResult.setTitle(
        chrome.i18n.getMessage('captiveportaldnstest_potential_problem_title'));
    this.testResult.setSubtitle(
        chrome.i18n.getMessage(
            'captiveportaldnstest_potential_problem_subtitle'));
  }
};


/**
 * See chromium/src/chrome/common/extensions/api/experimental_dns.idl for
 *   the definition of ResolveCallbackResolveInfo.
 * @param {chrome.experimental.dns.ResolveCallbackResolveInfo} resolverResult
 *   DNS query results.
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.resolveCallback_ = function(resolverResult) {
  window.clearTimeout(this.timeoutId_);
  if (resolverResult == undefined || resolverResult.resultCode == undefined) {
    // Resolution failed.
    this.testResult.addLogRecord('#' + this.numTestsCompleted_ +
        chrome.i18n.getMessage('captiveportaldnstest_noresult_code_returned'));

    this.testResult.setTestVerdict(ccd.TestVerdict.TEST_FAILURE_OCCURRED);
    this.executeCallback();
    return;
  } else {
    // Test succeeded (i.e., we got a result info we can analyze).
    this.resolutionResultsCode_.push(resolverResult.resultCode);
    this.testResult.addLogRecord('#' + this.numTestsCompleted_ +
        chrome.i18n.getMessage('captiveportaldnstest_log_statuscode_returned') +
        resolverResult.resultCode);

    // For some resolvers, resolverResult.address will be blank.
    // Check for this situation.
    if (resolverResult.address != undefined) {
      this.resolutionResultsString_.push(resolverResult.address);
      this.testResult.addLogRecord('#' + this.numTestsCompleted_ +
          chrome.i18n.getMessage('captiveportaldnstest_log_address_returned') +
          resolverResult.address);
    } else {
      // Need to push null in order to guarantee the array contains
      //   the proper number of elements, which preserves indexing.
      this.resolutionResultsString_.push(null);
      this.testResult.addLogRecord('#' + this.numTestsCompleted_ +
          chrome.i18n.getMessage('captiveportaldnstest_no_addr_returned'));
    }
  }

  this.numTestsCompleted_++;

  // Compute the total number of DNS resolution tests to run.
  var numTotalTestsToRun =
      ccd.CaptivePortalDnsTest.NUM_RANDOM_HOSTS_CAPTIVE_PORTAL_DNS_TEST_ +
      this.knownHostnamesToQuery_.length;
  if (this.numTestsCompleted_ >= numTotalTestsToRun) {
    this.analyzeResults();
    this.executeCallback();
  } else {
    // Allow code to be run synchronously to make testing easier.
    if (ccd.TestConfVars.RESOLVER_LATENCY_SLEEP_MILSEC > 0) {
      this.timeoutId_ = setTimeout(this.attemptResolution_.bind(this),
          ccd.TestConfVars.RESOLVER_LATENCY_SLEEP_MILSEC);
    } else {
      this.attemptResolution_();
    }
  }
};


/**
 * Attempt to resolve DNS for a hostname.
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.attemptResolution_ = function() {
  var hostname = '';
  if (this.numTestsCompleted_ < this.knownHostnamesToQuery_.length) {
    hostname = this.knownHostnamesToQuery_[this.numTestsCompleted_];
  } else {
    hostname = ccd.util.getRandomString(25);
    hostname += '.com';
  }
  this.testResult.addLogRecord(
      chrome.i18n.getMessage('captiveportaldnstest_beginning_resolution') +
      this.numTestsCompleted_ + ' / ' + hostname);

  chrome.experimental.dns.resolve(hostname,
                                  this.resolveCallback_.bind(this));
};


/**
 * Test for a DNS-based captive portal.
 * @param {function(ccd.TestResult)} callbackFnc
 *   Function to execute upon completion of test.
 */
ccd.CaptivePortalDnsTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;
  this.attemptResolution_();
};
