

/**
 * @fileoverview Chrome v2 packaged app background script.
 * @author ebeach@google.com (Eric Beach)
 */


/**
 * Listens for the app launching then creates the window
 *
 * @see http://developer.chrome.com/trunk/apps/app.runtime.html
 * @see http://developer.chrome.com/trunk/apps/app.window.html
 */
chrome.app.runtime.onLaunched.addListener(function() {
  var width = 800;
  var height = 600;
  chrome.app.window.create('index.html',
      {width: width, height: height});
});

/**
 * Listens for the extension asking us to launch the app
 */
chrome.runtime.onMessageExternal.addListener(
    function(request, sender, sendResponse) {
  if (request && request['command'] == 'launch') {
    var width = 800;
    var height = 600;
    chrome.app.window.create('index.html',
                             {width: width, height: height});
  }
});
