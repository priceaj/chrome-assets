

/**
 * @fileoverview Abstract utility class with helpful functions.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.util');


/**
 * Determine whether the client is running ChromeOS.
 * @return {boolean} Whether client running ChromeOS.
 */
ccd.util.isChromeOS = function() {
  var userAgent = navigator.userAgent;
  return (userAgent.indexOf(' CrOS ') != -1);
};


/**
 * Translate a microsecond timestamp (e.g., 1372094836900) to a string
 *   (e.g., "Mon Jun 24 2013 13:27:16 GMT-0400 (EDT)")
 * @param {number} microTimestamp Unix microtimestamp.
 * @return {string} Date formatted as "Mon Jun 24 2013 13:27:16 GMT-0400 (EDT)".
 */
ccd.util.printMicroTimestamp = function(microTimestamp) {
  var date = new Date(microTimestamp);
  return date.toString();
};
