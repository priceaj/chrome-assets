

/**
 * @fileoverview Chrome v2 packaged app background script.
 * @author ebeach@google.com (Eric Beach)
 */


/**
 * Listens for the app launching then creates the window.
 *
 * @see http://developer.chrome.com/trunk/apps/app.runtime.html
 * @see http://developer.chrome.com/trunk/apps/app.window.html
 */
chrome.app.runtime.onLaunched.addListener(function() {
  var width = 800;
  var height = 600;
  chrome.app.window.create('index.html',
      {frame: 'none', width: width, height: height,
       minWidth: 800, minHeight: 600});
});
