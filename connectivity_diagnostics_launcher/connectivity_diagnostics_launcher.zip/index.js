chrome.runtime.sendMessage(
    "kodldpbjkkmmnilagfdheibampofhaom",
    {command: "launch"}, function(res) { console.log(res); });
