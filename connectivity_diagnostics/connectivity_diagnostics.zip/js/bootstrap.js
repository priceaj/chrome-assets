

/**
 * @fileoverview Bootstrap the management of the GUI.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd');
goog.provide('ccd.Bootstrap');

goog.require('ccd.GuiManager');



/**
 * Bootstrap the network debugger app.
 *
 * @constructor
 */
ccd.Bootstrap = function() {
  /**
   * @private {ccd.GuiManager}
   */
  this.guiManager_ = new ccd.GuiManager();
  this.guiManager_.constructDom();
  this.guiManager_.runTests();
};

goog.exportSymbol('ChromeConnectivityDebugger', ccd.Bootstrap);
